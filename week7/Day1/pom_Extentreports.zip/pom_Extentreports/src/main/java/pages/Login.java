package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Login extends ProjectSpecificMethod {
	
	@Given ("enter the username as {string}")
	public Login enterUsername(String uName) throws IOException {
		
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep("uname entered sucessfully","pass");
		} catch (Exception e) {
			reportStep("uname not entered sucessfully","fail");
		}
		return this;
	}
	@And ("enter the password as {string}")
	public Login enterPassword(String pWord) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
			reportStep("pword entered sucessfully","pass");
		} catch (Exception e) {
			reportStep("pword not entered sucessfully","fail");
			//throw new RuntimeException("see the reprterdetails");
		}
		return this;
	}
	@When( "click on login button")
	public WelcomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
}
