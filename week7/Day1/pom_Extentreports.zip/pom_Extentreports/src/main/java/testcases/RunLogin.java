package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.Login;

public class RunLogin extends ProjectSpecificMethod {
	@BeforeTest
	public void setValues() {
		fileName="login";
		testName="login";
		testDescription="login with positive credentials";
		testCategory="smoke";
		testAuthor="Saranya";
	}
	@Test(dataProvider="sendData")
	public void runLogin(String uName,String pWord) throws IOException {
		
		//System.out.println("from r.l:"+driver);
			
			Login lp=new Login();
			
			lp.enterUsername(uName).enterPassword(pWord).clickLogin();
			
			
		}
}
